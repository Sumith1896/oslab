/* A multi threaded server */
#include <iostream>
#include <fcntl.h>
#include <stdio.h>
#include <string>
#include <set>
#include <queue>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <pthread.h>

using namespace std;

// request queue
std::queue<int> rq;
// curr queue size
int curr_size = 0;
// request queue limit (0 for unbounder)
int max_size;
// lock for the request queue
pthread_mutex_t queue_mutex = PTHREAD_MUTEX_INITIALIZER;
// condvar for queue not empty
pthread_cond_t queue_not_empty = PTHREAD_COND_INITIALIZER;
// condvar for queue not full
pthread_cond_t queue_not_full = PTHREAD_COND_INITIALIZER;

/* The problem to be handled here can be clearly reduced 
to the producer-consumer problem and has been handled with 
two condvars. Request queue being bounded or unbounded are
two variations of the problem, bounded or unbounded buffers */

void* worker(void* arg) {
	int sock;

	while(true) {
		// lock the queue to modify the request queue
		pthread_mutex_lock(&queue_mutex);
		while(curr_size == 0) {
			// if the queue is empty, wait for new sockets
			pthread_cond_wait(&queue_not_empty, &queue_mutex);
		}
		// service the front of the queue and pop
		sock = rq.front();
		rq.pop();
		curr_size--;
		// signal that the queue is not full and elements can be inserted
		pthread_cond_signal(&queue_not_full);
		// unlock the request queue
		pthread_mutex_unlock(&queue_mutex);

		int n;
		// buffer to read in from the socket
		char buffer[256];
		bzero(buffer,256);

		// initially read from the socket
		n = read(sock,buffer,255);
		   
		// error handling
		if (n < 0) {
			perror("ERROR reading from socket");
			pthread_exit(NULL);
		}
		
		// get the filename requested by the client
		// command `get <filename>`, get the exact filename at offset of 4
		char filename[1024];
		strncpy(filename, buffer + 4, sizeof(buffer));
		// get the file descriptor to the requested file
		// cout << filename << endl;
		int input_file = open(filename, O_RDONLY);

		// a loop to send the file in chunks
		int total = 0;
		while (1) {
			// read from the file descriptor
			int bytes_read = read(input_file, buffer, sizeof(buffer));
			// if done terminate
			if (bytes_read == 0) {
				break;
			}
			// error handling
			if (bytes_read < 0) {
				perror("ERROR during reading file requested");
				pthread_exit(NULL);
			}
			// send the chunk read of the file on the socket
			char *p = buffer;
			int bytes_written;
			while(bytes_read > 0) {
			    bytes_written = send(sock, p, bytes_read, 0);
			    if (bytes_written <= 0) {
					perror("ERROR during writing file on socket");
					pthread_exit(NULL);
			    } else {
			    	total += bytes_written;
			    }
			    bytes_read -= bytes_written;
			    p = p + bytes_written;
			}
		}
		// close the file descriptor	
		// cout << "Finished sending" << endl;
		close(input_file);
		close(sock);
	}
	pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
	
	int portno, n_workers;
	if (argc != 4) {
		perror("Invalid number of arguments");
		return -1;
	} else {
		portno = stoi(argv[1]);
		n_workers = stoi(argv[2]);
		max_size = stoi(argv[3]);
	}

	int sockfd, newsockfd;
	struct sockaddr_in serv_addr, cli_addr;

	pthread_t threads[n_workers];
	for(int i = 0; i < n_workers; i++) {
		int rc = pthread_create(&threads[i], NULL, worker, NULL);
		if (rc){
			wcerr << "Error on worker thread creation, " << rc << endl;
			i--;
			exit(-1);
		}
	}

	/* create socket */

    serv_addr.sin_family = AF_INET; // host byte order works for this
    serv_addr.sin_port = htons(portno); // convert to network byte order, short
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    memset(&(serv_addr.sin_zero), '\0', 8); // zero the rest of the struct

    sockfd = socket(AF_INET, SOCK_STREAM, 0); // setting up socket fd
    if (sockfd < 0) {
        perror("Error on opening socket");
        return -1;
    }

    int yes = 1; // remove the address already in use
    if (setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(int)) == -1) {
        perror("setsockopt");
        return -1;
    }

    if(bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(struct sockaddr)) < 0) { // binding socket and address
        perror("Could not bind the socket");
        return -1;
    }

    if(listen(sockfd, 5) < 0) { //listening
        perror("Error on listening");
        return -1;
    }

	socklen_t clilen = sizeof(cli_addr);

	while (1) {
		// loop to accept new connections
		newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

		if (newsockfd < 0) {
			perror("Error on accept");
	        return -1;
		}

		// lock the queue during modification
		pthread_mutex_lock(&queue_mutex);
		if(max_size != 0) {
			// if the queue is bounded, sleep on full
			while(curr_size >= max_size) {
				pthread_cond_wait(&queue_not_full, &queue_mutex);
			}
		}
		// push the accepted socket
		rq.push(newsockfd);
		curr_size++;
		// signal the queue not empty
		pthread_cond_signal(&queue_not_empty);
		// release the lock 
		pthread_mutex_unlock(&queue_mutex);

	} /* end of while */

    return 0;
}
