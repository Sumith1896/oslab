SETUP DETAILS
=============
We have used 2 machines in the New Software Lab 2 as a Client and Server for the
process of conducting experiments on our application. Each machine has the following
specifications:

	- Processor: Intel® Core™ i5-3330 CPU @ 3.00GHz × 4
	- Memory: 8 GB
	- Ethernet Card: 1 Gbit/s

Both machines are connected to each other using ethernet cables and a switch in the
NSL Network.

RUNNING INSTRUCTIONS
====================
To compile the code:

```
make all
```

This creates the required executable of server.

Sample server run:
```
./server-mt 5000 10 500
```
