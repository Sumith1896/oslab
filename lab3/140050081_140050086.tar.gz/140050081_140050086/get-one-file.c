#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#include <pthread.h>
#include <time.h>
#include <csignal>

#define usage "./get-one-file <filename> <ip> <port> <display>"
#define BUF_SIZE 256

using namespace std;

int main(int argc, char *argv[])
{

	char serv_ip[256];
	int serv_port;
	char filename[256];
	char display[20];
	bool toDisplay = false;

	if (argc < 5) {
		printf("Usage: %s", usage);
		exit(0);
	}

	strcpy(filename, argv[1]);
	strcpy(serv_ip, argv[2]);
	serv_port = atoi(argv[3]);
	strcpy(display, argv[4]);
	string disp(display);
	if(disp == "display")
		toDisplay = true;
	else if(disp == "nodisplay")
		toDisplay = false;
	else {
		// error
	}

	struct sockaddr_in serv_addr;
	serv_addr.sin_family = AF_INET; // host byte order works for this
	serv_addr.sin_port = htons(serv_port); // convert to network byte order, short
	if(inet_aton(serv_ip, &(serv_addr.sin_addr)) == 0) { // can also pick up ip directly from machine: Beej pg 14
		perror("Error on assigning IP address to socket");
		pthread_exit(NULL);
	}

	memset(&(serv_addr.sin_zero), '\0', 8); // zero the rest of the struct

	int my_sockfd = socket(AF_INET, SOCK_STREAM, 0); // setting up socket fd

	if (my_sockfd < 0) {
		perror("Error on opening socket");
		pthread_exit(NULL);
	}
	
	if(connect(my_sockfd, (struct sockaddr *)&serv_addr, sizeof(struct sockaddr)) < 0) { // binding socket and address 
		perror("Could not connect to destination");
		pthread_exit(NULL);
	}
	int yes = 1;
	if (setsockopt(my_sockfd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(int)) == -1) { // remove the address already in use
		perror("setsockopt");
		pthread_exit(NULL);
	}

	string str(filename);
	char data[BUF_SIZE];
	strcpy(data,str.c_str()); data[str.length()] = '\0';
	int len = strlen(data);
	int bsent = send(my_sockfd, data, len, 0);

	if(bsent != len) {
		perror("Sorry, the whole message wasn't sent!");
		pthread_exit(NULL);
	}

	char buf[256];
	int total_read = 0;

	while (true) {
		int numbytes= recv(my_sockfd, buf, sizeof(buf), 0);
		buf[numbytes] = '\0';
		if(toDisplay)
			cout << buf;
		total_read += numbytes;
		if (numbytes == 0) {
			break;
		}
		else if(numbytes == -1) { //Error

		}
	}
	close(my_sockfd);
	// printf("Done!\n");
	
	return 0;
}

