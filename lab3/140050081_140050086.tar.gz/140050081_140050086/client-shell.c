#include <iostream>
#include <bits/stdc++.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <mutex>

using namespace std;

#define MAX_TOKEN_SIZE 64
#define MAX_NUM_TOKENS 64
#define PROMPT "Hello> "
#define SLEEP_TIME 1

// Global variables declarations
static string WorkingDir = "";
static string serverIP = "";
static string serverPORT = "";
static mutex bgPidLock;
static int numBG = 0;
static pid_t bgPGID = 0;
static pthread_t bgThread;
static bool runningSomething = false;

// Function declarations
char **tokenize(string line);
int argCount(char** tokens);
void printPrompt();
void terminateFG(int signum);
void terminateBG(int signum);
void* reapBG(void* arg);
void signalHandler(int signum);
bool existServerDetails();
void checkServerDetails();
int indexPipe(char** tokens);
int indexRedirect(char** tokens);
char** getFile(char*fname, bool display);
template <class T>
void freeMemory(T** ptr);
template <class T>
void freeMemory(T** ptr, int start, int end);
template <class T>
T* shiftArr(T* tokens, int start, int end);
void runCommand(char **tokens);

int main(int argc, char const *argv[]) {

	char pbuf[1024];
	if (getcwd(pbuf, sizeof(pbuf)) != NULL) {
		// Store working directory to successfully access 
		// ./get-one-file-sig even after using cd
		WorkingDir = string(pbuf) + string(&argv[0][1]);
		WorkingDir = WorkingDir.substr(0,WorkingDir.find_last_of('/'));
	}

	// Set signal handler
	signal(SIGINT, signalHandler);

	// Creating thread for reaping background processes
	long redundantArg=0;
	int rc = pthread_create(&bgThread, NULL, reapBG, (void*)redundantArg);
	if (rc){
		wcerr << "Error:unable to create thread," << rc << endl;
		exit(-1);
	}

	// Variables used during shell execution
	string input;
	char* cmd;
	pid_t pid;
	char **tokens = NULL;

	while(true)	{ // Continuous loop of the shell

		printPrompt();

		// Get shell input
		runningSomething = false;
		getline(cin, input);
		runningSomething = true;

		// Check if input stream is open
		if (! cin.good()) {
			terminateFG(SIGINT);
			terminateBG(SIGINT);
			exit(0);
		}

		if (input.length()<=0) // No input
			continue;

		// Free old tokens memory, get new tokens
		freeMemory(tokens);
		tokens = tokenize(input);
		if (tokens == NULL)
			continue;
		cmd = tokens[0]; // The first command


		if(strcmp(cmd,"cd") == 0) { // Change Dir
			if(argCount(tokens)!=2) { // Check number of arguments
				wcerr<<"Usage: cd <path>"<<endl;
			}
			else {
				if(chdir(tokens[1]) < 0) { // Error Handling
					string errorMessage;
					if(errno==ENOENT)
						errorMessage="No such file or directory";
					else if(errno==ENAMETOOLONG)
						errorMessage="Path too long";
					else if(errno==EACCES)
						errorMessage="Permission denied";
					else if(errno==ENOTDIR)
						errorMessage="Not a directory";
					else if(errno==ELOOP)
						errorMessage="Loop in symbolic link";

					cout<<"cd: "<<tokens[1]<<": "<<errorMessage<<endl;
				}
			}
		}
		else if(strcmp(cmd,"server") == 0) { // Store serverIP and Port
			if(argCount(tokens)!=3) {
				wcerr<<"Usage: server <ip> <port>"<<endl;
			}
			else {
				serverIP = string(tokens[1]);
				serverPORT = string(tokens[2]);
			}
		}
		else if(strcmp(cmd,"ser") == 0) { // For convenience while debugging
			serverIP = "127.0.0.1";
			serverPORT = "5000";
		}
		else if(strcmp(cmd,"exit") == 0) {
			terminateFG(SIGINT); // Terminate Foreground processes
			terminateBG(SIGINT); // Terminate Background processes
			exit(0);
		}
		else {

			// Check if server details are needed, at least one file is supplied
			if (strcmp(cmd,"getfl")==0 || strcmp(cmd,"getbg")==0 ||
				strcmp(cmd,"getpl")==0 || strcmp(cmd,"getsq")==0) {
				if(!existServerDetails()){
					wcerr<<"Error: Server details missing."<<endl;
					wcerr<<"Use server <IP> <PORT> to set server deatails"<<endl;
					continue;
				}
				if(argCount(tokens) < 2) {
					wcerr<<"Error: No filenames supplied"<<endl;
					continue;
				}
			}

			// Fork a child for executing the input command
			switch(pid = fork()) {

				case -1: //Error
					wcerr<<"fork: Error"<<endl;
					break;

				case 0: //Child

					signal(SIGINT, SIG_DFL); // Restore default signal handler

					if(strcmp(cmd,"getbg") == 0) {	// Background Process
						if (numBG == 0) {
							bgPGID = pid;
						}
						if (setpgid(pid, bgPGID) < 0) // Change PGID
							wcerr<<"setpgid: Error: "<<strerror(errno)<<endl;
					}

					runCommand(tokens); // Runs tokens, never returns
					break;

				default: //Parent
					if(strcmp(cmd,"getbg") == 0) {	// The child is a Background Process

						bgPidLock.lock();
						if (numBG == 0) { // Store PGID for future bg processes
							bgPGID = pid;
						}
						bgPidLock.unlock();

						if (setpgid(pid, bgPGID) < 0) // Change PGID
							wcerr<<"setpgid: Error: "<<strerror(errno)<<endl;

						// Keep a count of bg processes to decide if the old PGID can be used
						bgPidLock.lock();
						numBG++;
						bgPidLock.unlock();
					}
					else { // The child is a Foreground Process, Wait
						waitpid(pid, NULL, 0);
					}
			}
		}
	}

	return 0;
}

void runCommand(char **tokens) {

	if(tokens==NULL) { // Error handling
		wcerr<<"NULL command encountered"<<endl;
		exit(-1);
	}

	char *cmd = tokens[0];
	int posPipe = indexPipe(tokens);			// Index of pipe token
	int posRedirect = indexRedirect(tokens);	// Index of redirect token

	if(posRedirect == -2) { // More than one redirect token found
		wcerr<<tokens[0]<<": Incorrect IO redirection"<<endl;
		exit(-1);
	}

	if(posPipe>=0 && posRedirect>=0) { // Both pipe and redirect tokens found
		wcerr<<tokens[0]<<": Incorrect use of pipes and IO redirection"<<endl;;
		exit(-1);
	}

	if(posRedirect>=0) { // Handle IO redirection to file
		if (tokens[posRedirect+2] != NULL) { // Check number of arguments
			wcerr<<tokens[0]<<": Incorrect IO redirection"<<endl;
			exit(-1);
		}

		int fd = creat(tokens[posRedirect+1], 0644); // get fd to output file
		if (dup2(fd, STDOUT_FILENO)<0) { // Duplicate fd to stdout
			wcerr<<tokens[0]<<": dup2: "<<strerror(errno)<<endl;
			exit(-1);
		}
		// Close extra file descriptors, free memory that is not needed anymore
		close(fd);
		freeMemory(tokens, posRedirect+1, -1);
		tokens[posRedirect]=NULL;
	}

	if(posPipe>=0) { // Handle IO redirection via pipes
		int fd[2];
		if (pipe(fd)<0) { // Create pipe fds
			wcerr<<cmd<<": pipe: "<<strerror(errno)<<endl;
			exit(-1);
		}
		pid_t pidRight;
		switch(pidRight=fork()) {
			case -1: {				// Failed
				wcerr<<cmd<<": fork: "<<strerror(errno)<<endl;
				exit(-1);
			}
			case 0: {				// Child that will execute right side
				if (dup2(fd[0], STDIN_FILENO)<0) { // copy pipe fd to stdin
					wcerr<<cmd<<": dup2: "<<strerror(errno)<<endl;
					exit(-1);
				}

				// Close extra file descriptors, free memory that is not needed anymore
				close(fd[0]);
				close(fd[1]);
				int tokenSize = argCount(tokens);
				freeMemory(tokens, 0, posPipe);
				tokens = shiftArr(tokens, posPipe+1, tokenSize);

				// Run right side of pipe
				runCommand(tokens);
			}
			default: {				// Parent
				freeMemory(tokens, posPipe+1, -1);
				tokens[posPipe]=NULL;
			}
		}

		pid_t pidLeft;
		switch(pidLeft=fork()) {
			case -1: {				// Failed
				wcerr<<cmd<<": fork: "<<strerror(errno)<<endl;
				exit(-1);
			}
			case 0:	{				// Child that will execute left side
				if (dup2(fd[1], STDOUT_FILENO)<0) { // copy pipe fd to stdout
					wcerr<<cmd<<": dup2: "<<strerror(errno)<<endl;
					exit(-1);
				}

				// Close extra file descriptors
				close(fd[0]);
				close(fd[1]);

				// Run left side of pipe
				runCommand(tokens);
			}
			default: {				// Parent
				// Close extra file descriptors, free memory that is not needed anymore
				close(fd[0]);
				close(fd[1]);

				// Wait for left and right child processes
				waitpid(pidRight,NULL,0);
				waitpid(pidLeft,NULL,0);
				exit(0);
			}
		}
	}

	if(strcmp(cmd,"getfl") == 0 || strcmp(cmd,"getbg") == 0) { // Get single file
		if (argCount(tokens) != 2) {
			wcerr<<"Usage: "<<cmd<<" <filePath>"<<endl;
			exit(-1);
		}
		checkServerDetails(); // Check if server details are available

		if (strcmp(cmd,"getfl")==0)
			getFile(tokens[1], true); // display output
		else
			getFile(tokens[1], false); // dont display output
	}
	else if(strcmp(cmd,"getsq") == 0) {
		if (argCount(tokens) < 2) {
			wcerr<<"Usage: "<<cmd<<" <filePath1> <filePath2> ..."<<endl;
			exit(-1);
		}
		checkServerDetails(); // Check if server details are available

		int numFiles = argCount(tokens)-1;
		int currFile = 0;
		pid_t pid;
		while(currFile<numFiles) {
			switch(pid=fork()) {
				case -1: {				// Failed
					wcerr<<cmd<<": fork: "<<strerror(errno)<<endl;
					exit(-1);
				}
				case 0: {				// Child
					getFile(tokens[currFile+1],false);
				}
				default: {				// Parent
					if(waitpid(pid,NULL,0)<0) { // Wait for child before next fork
						wcerr<<cmd<<": waitpid: "<<strerror(errno)<<endl;
						exit(-1);
					}
					currFile++;
				}
			}
		}
		exit(0);
	}
	else if(strcmp(cmd,"getpl") == 0) {
		if (argCount(tokens) < 2) {
			wcerr<<"Usage: "<<cmd<<" <filePath1> <filePath2> ..."<<endl;
			exit(-1);
		}
		checkServerDetails(); // Check if server details are available

		int numFiles = argCount(tokens)-1;
		int currFile = 0;
		pid_t pid[numFiles]; // Store pids of child processes
		while(currFile<numFiles) {
			switch(pid[currFile]=fork()) {
				case -1: {				// Failed
					wcerr<<cmd<<": fork: "<<strerror(errno)<<endl;
					exit(-1);
				}
				case 0: {				// Child
					getFile(tokens[currFile+1],false);
				}
				default: {				// Parent
					// Dont wait for child before next fork
					currFile++;
				}
			}
		}
		// Dont wait for all children created
		for(int i=0;i<numFiles;i++ ) {
			if(waitpid(pid[i],NULL,0)<0) {
				wcerr<<cmd<<": waitpid: "<<strerror(errno)<<endl;
				exit(-1);
			}
		}
		exit(0);
	}
	else {
		// All other unrecognised commands are run using execvp
		// This enables us to execule a much wider range of commands 
		// and not only simple linux commands
		execvp(cmd,tokens);

		// Error handling
		wcerr<<"Error executing "<<cmd<<": "<<strerror(errno)<<endl;
		exit(-1);
	}

	exit(0); // For completeness
}

char **tokenize(string line) { 
	// The same function that was provided
	// Contains only minor changes
	// Uses a string instead of char*
	// Reads '|' and '>' into new (separate) tokens
	// '\' has been implemented as an escape character

	line = line+'\n';
	char **tokens = (char **)malloc(MAX_NUM_TOKENS * sizeof(char *));
	char *token = (char *)malloc(MAX_TOKEN_SIZE * sizeof(char));
	uint i;
	int tokenIndex = 0, tokenNo = 0;
	bool escapeNext=false;

	for(i =0; i < line.length(); i++) {

		char readChar = line[i];

		if ((readChar == ' ' || readChar == '\n' || readChar == '\t' || readChar == '\0'
			|| readChar == '|' || readChar == '>'
			)
			&& !escapeNext
			) {
			token[tokenIndex] = '\0';
			if (tokenIndex != 0){
				tokens[tokenNo] = (char*)malloc(MAX_TOKEN_SIZE*sizeof(char));
				strcpy(tokens[tokenNo++], token);
				tokenIndex = 0;
			}
			if (readChar == '|' || readChar == '>') {
				token[tokenIndex++] = readChar;
				token[tokenIndex] = '\0';
				tokens[tokenNo] = (char*)malloc(MAX_TOKEN_SIZE*sizeof(char));
				strcpy(tokens[tokenNo++], token);
				tokenIndex = 0;
			}
		}
		else {
			if(readChar!='\\' || escapeNext)
				token[tokenIndex++] = readChar;

			if(!escapeNext)
				escapeNext = (readChar=='\\');
			else
				escapeNext=false;
		}
	}

	free(token);
	tokens[tokenNo] = NULL ;

	return tokens;
}

int argCount(char** tokens) {
	// Returns the number of tokens
	if(tokens == NULL)
		return 0;

	int i=0;
	while(tokens[i]!=NULL)
		i++;

	return i;
}

template <class T>
void freeMemory(T** ptr) {
	// Frees all memory allocated to T
	if(ptr==NULL)
		return;

	for (int i = 0; ptr[i]!=NULL; ++i)
	{
		free(ptr[i]);
	}

	free(ptr);
	return;
}

template <class T>
void freeMemory(T** ptr, int start, int end) {
	// Frees all memory allocated to T from start to end
	if (end<0) {
		for(int i=start; ptr[i-end+1]!=NULL; i++) {
			free(ptr[i]);
		}
	}
	else {
		for(int i=start; i<=end; i++) {
			free(ptr[i]);
		}
	}
}

template <class T>
T* shiftArr(T* tokens, int start, int end) {
	// Frees all memory allocated to T, 
	// returns a new array containing elements from start to end
	T* tokensTemp = (T*)malloc((end-start+1) * sizeof(T));
	memcpy(tokensTemp,(tokens+start),(end-start+1) * sizeof(T));
	free(tokens);
	return tokensTemp;
}

void printPrompt() {
	cout<<PROMPT;
	cout.flush();
	return;
}

void terminateFG(int signum) {
	// Terminate all foreground processes
	if(kill(0,signum)<0) { // Kill all processes with PGID == PGID of caller (shell)
		wcerr<<getpid()<<": terminateFG: "<<signum<<": Error: "<<strerror(errno)<<""<<endl;
	}
	while(true) {
		if (waitpid(0,NULL,0) <= 0)
			if (errno == ECHILD)
				break;
	}
}

void terminateBG(int signum) {
	// Terminate all background processes
	while(numBG>0) {
		if (kill(-bgPGID,signum) > 0) { // Kill all background processes using their common PGID
			bgPidLock.lock();
			numBG--;
			bgPidLock.unlock();
		}
		else if (errno == ECHILD)
			break;
	}
	while(true) { // To ensure the children are dead before exiting, an extra check
		if (waitpid(-bgPGID,NULL,0) <= 0)
			if (errno == ECHILD)
				break;
	}
}

void* reapBG(void* arg) { // Reaps bg processes 
	while(true) {
		pid_t reaped = -1;
		bool breakNow = false;
		while(!breakNow) {
			switch(reaped = waitpid(-bgPGID, NULL, WNOHANG)) { // Reaps bg processes using bgPGID until no such dead child exists
				case 0:
					breakNow = true;
					break;
				case -1:
					if(errno != ECHILD)
						wcerr<<"reapBG: "<<strerror(errno)<<""<<endl;
					breakNow = true;
					break;
				default:
					cout<<"\nBackground process "<<reaped<<" terminated"<<endl;

					bgPidLock.lock();
					numBG--;
					bgPidLock.unlock();
			}
		}
		sleep(SLEEP_TIME);
	}
	return NULL;
}

void signalHandler(int signum) { 
	// No need to kill child foreground processes
	// We noticed that they are automatically killed because of their PGID
	while(true) {
		if (waitpid(0,NULL,0) <= 0)
			if (errno == ECHILD)
				break;
	}
	cout<<endl;
	if ( !runningSomething ) {
		printPrompt();
	}
	return;
}

bool existServerDetails() {
	return (serverIP!="" && serverPORT!="");
}

void checkServerDetails() {
	if(!existServerDetails()){
		wcerr<<"Error: Server details missing."<<endl;
		wcerr<<"Use server <IP> <PORT> to set server deatails"<<endl;
		exit(0);
	}
}

int indexPipe(char** tokens) {
	// Returns first index of '|'
	if(tokens==NULL)
		return -1;

	int posFound = -1;
	for (int i = 0; tokens[i]!=NULL; ++i) {
		if(strcmp("|",tokens[i]) == 0) {
			// if(posFound>=0)
			// 	return -2;

			// posFound = i;
			return i;
		}
	}
	return posFound;
}

int indexRedirect(char** tokens) {
	// Returns first index of '>', -2 if multiple
	if(tokens==NULL)
		return -1;

	int posFound = -1;
	for (int i = 0; tokens[i]!=NULL; ++i) {
		if(strcmp(">",tokens[i]) == 0) {
			if(posFound>=0)
				return -2;

			posFound = i;
		}
	}
	return posFound;
}

char** getFile(char* fname, bool display) {
	// Download fname from server
	char *arguments[6];
	for(int i=0;i<6;i++) {
		arguments[i] = new char[64];
	}
	if (WorkingDir == "") {
		strcpy(arguments[0],"./get-one-file-sig");
	}
	else {
		strcpy(arguments[0],(WorkingDir+"/get-one-file-sig").c_str());
	}
	
	strcpy(arguments[1],fname);
	strcpy(arguments[2],serverIP.c_str());
	strcpy(arguments[3],serverPORT.c_str());
	strcpy(arguments[4],(display)?("display"):("nodisplay"));
	arguments[5] = NULL;

	execvp(arguments[0],arguments);

	// Error handling
	wcerr << arguments[0] << ": " << strerror(errno) <<endl;
	exit(-1);
}
