#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "fcntl.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"

int a = 1;

void
testcow(void) {

  printf(1, "\n\n\nRunning testcow()...\n");
  printf(1, "Before fork %d, a = %d, phy addr. = %p and numFree = %d\n",getpid(), a, viphy(&a), getNumFreePages());
  printf(1, "Forking now...\n");

  if(fork() == 0) {
    printf(1, "Child %d, a = %d, phy addr. = %p and numFree = %d\n",getpid(), a, viphy(&a), getNumFreePages());
    sleep(100);
    printf(1, "Updating a in child...\n");
    a = 2;
    printf(1, "Child %d, a = %d, phy addr. = %p and numFree = %d\n",getpid(), a, viphy(&a), getNumFreePages());
    exit();
  } else {
    printf(1, "Parent %d, a = %d, phy addr. = %p and numFree = %d\n",getpid(), a, viphy(&a), getNumFreePages());
    while(wait()!=-1);
    printf(1, "Child reaped...\n");
    printf(1, "Parent %d, a = %d, phy addr. = %p and numFree = %d\n",getpid(), a, viphy(&a), getNumFreePages());
  }

  return;
}

void
testcowmult(void) {

  printf(1, "\n\n\nRunning testcowmult()...\n");
  printf(1, "Before fork %d, a = %d, phy addr. = %p and numFree = %d\n",getpid(), a, viphy(&a), getNumFreePages());
  printf(1, "Forking 3 new processes now...\n");

  if(fork() == 0) {
    if(fork() == 0) {
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());

      sleep(50);
      printf(1, "\n\nUpdating a in %d...\n",getpid());
      a = 2;
      sleep(200);

      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());

      sleep(200);
      exit();
    }
    else {
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());

      sleep(50);
      printf(1, "\n\nUpdating a in %d...\n",getpid());
      a = 3;
      sleep(200);

      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());

      sleep(200);
      wait();
      exit();
    }
  } else {
    if(fork() == 0) {
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());

      sleep(50);
      printf(1, "\n\nUpdating a in %d...\n",getpid());
      a = 4;
      sleep(200);

      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());

      sleep(200);
      exit();
    }
    else {
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());
      sleep(250);
      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());

      sleep(50);
      printf(1, "\n\nUpdating a in %d...\n",getpid());
      a = 2;
      sleep(200);

      printf(1, "Process %d, phy addr. = %p and numFree = %d\n",getpid(), viphy(&a), getNumFreePages());

      sleep(200);
      wait();
    }

    wait();
  }
  printf(1, "\n\nAfter reaping %d, a = %d, phy addr. = %p and numFree = %d\n",getpid(), a, viphy(&a), getNumFreePages());


  return;
}

int
main(int argc, char *argv[])
{
  printf(1, "Testing CoW implementation...\n");

  // test forking a single child
  testcow();

  // exhaustive test with multiple children
  testcowmult();

  exit();
}
