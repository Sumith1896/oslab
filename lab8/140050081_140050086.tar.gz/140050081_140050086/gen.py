for i in range(10):
	file1 = open('testA' + str(i), 'w')
	for k in range(i):
		for j in range(4096):
			file1.write('a')
	for k in range(16-i):
		for j in range(4096):
			file1.write('b')
			