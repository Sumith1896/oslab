OS Lab 7 - Understanding Filesystems
------------------------------------

- The instructions and code to run the file is present in the
Experimental evaluation section of report.pdf

- The files used were the same files generated in previous lab.

Commands used for cpu measurement:
----------------------------------
sumith1896@yoda:~$ iostat -c -d 2 > on.txt

sumith1896@yoda:~$ iostat -c -d 2 > off.txt
