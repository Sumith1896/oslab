/* A multi process servers that reaps it's children 😮 */
#include <iostream>
#include <fcntl.h>
#include <stdio.h>
#include <string>
#include <set>
#include <queue>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

using namespace std;

void sigchld_handler(int s) {
	// Handler defined for reaping childer
	// Beej's guide: page 25
	int saved_errno = errno;
	while(waitpid(-1, NULL, WNOHANG) > 0);
	errno = saved_errno;
}

void handlechild(int sock) {
	int n;
	// buffer to read in from the socket
	char buffer[256];
	bzero(buffer,256);

	// initially read from the socket
	n = read(sock,buffer,255);
	   
	// error handling
	if (n < 0) {
		perror("ERROR reading from socket");
		return;
	}
	
	// get the filename requested by the client
	// command `get <filename>`, get the exact filename at offset of 4
	char filename[1024];
	strncpy(filename, buffer + 4, sizeof(buffer));
	// get the file descriptor to the requested file
	int input_file = open(filename, O_RDONLY);

	// a loop to send the file in chunks
	while (1) {
		// read from the file descriptor
		int bytes_read = read(input_file, buffer, sizeof(buffer));
		// if done terminate
		if (bytes_read == 0)
			break;
		// error handling
		if (bytes_read < 0) {
			perror("ERROR during reading file requested");
			return;
		}
		// send the chunk read of the file on the socket
		char *p = buffer;
		while(bytes_read > 0) {
		    int bytes_written = send(sock, p, bytes_read, 0);
		    if (bytes_written <= 0) {
				perror("ERROR during writing file on socket");
				return;
		    }
		    bytes_read -= bytes_written;
		    p = p + bytes_written;
		}
	}
	// close the file descriptor	
	close(input_file);
}


int main(int argc, char *argv[]) {
	int sockfd, newsockfd, portno;
	struct sockaddr_in serv_addr, cli_addr;
	int pid;
	struct sigaction sa;

	if (argc < 2) {
		perror("Invalid number of arguments");
		return -1;
	} else {
		portno = stoi(argv[1]);
	}

	/* create socket */

    serv_addr.sin_family = AF_INET; // host byte order works for this
    serv_addr.sin_port = htons(portno); // convert to network byte order, short
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    memset(&(serv_addr.sin_zero), '\0', 8); // zero the rest of the struct

    sockfd = socket(AF_INET, SOCK_STREAM, 0); // setting up socket fd
    if (sockfd < 0) {
        perror("Error on opening socket");
        return -1;
    }

    int yes = 1; // remove the address already in use
    if (setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(int)) == -1) {
        perror("setsockopt");
        return -1;
    }

    if(bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(struct sockaddr)) < 0) { // binding socket and address
        perror("Could not bind the socket");
        return -1;
    }

    if(listen(sockfd, 5) < 0) { //listening
        perror("Error on listening");
        return -1;
    }

	socklen_t clilen = sizeof(cli_addr);

	sa.sa_handler = sigchld_handler; // reap all dead processes
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = SA_RESTART;
	if (sigaction(SIGCHLD, &sa, NULL) == -1) {
		perror("sigaction");
		exit(1);
	}

	while (1) {
		// loop to accept new connections
		newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

		if (newsockfd < 0) {
			perror("Error on accept");
	        return -1;
		}

		/* Create child process */
		pid = fork();

		if (pid < 0) {
			perror("ERROR on fork");
			exit(1);
		}

		if (pid == 0) {
			/* This is the client process */
			close(sockfd);
			handlechild(newsockfd);
			exit(0);
		}
		else {
			close(newsockfd);
		}
		
	} /* end of while */

    return 0;
}
