#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#include <pthread.h>
#include <time.h>

#define usage "multi-client <IP> <port> <users> <duration> <think-time> <mode>"
#define MAX_THREADS 500
#define BUF_SIZE 256

using namespace std;

void *new_user(void *threadid);

// Global variables to be used by every thread (user)
// Variable names are self-explanatory
char serv_ip[256];
int serv_port;
int users;
int duration;
int think_time;
string mode;

// Arrays for storing the timing results obtained by each thread
int requests_served[MAX_THREADS];
float response_times[MAX_THREADS];

int main(int argc, char *argv[])
{

	if (argc < 7) { // Check usage
		printf("Usage: %s", usage);
		exit(0);
	}

	// populate global variables
	strcpy(serv_ip,argv[1]);
	serv_port = atoi(argv[2]);
	users = atoi(argv[3]);
	duration = atoi(argv[4]);
	think_time = atoi(argv[5]);
	mode = string(argv[6]);

	pthread_t threads[MAX_THREADS]; // Stores thread ids

	time_t experiment_started = time(NULL);

	for(int i=0;i<users;i++) {
		printf("Creating thread %d\n",i);
		// Creating thread i
		int rc = pthread_create(&threads[i], NULL, new_user, (void *)(long)i);
		if (rc){
			printf("ERROR; return code from pthread_create() is %d\n", rc);
			i--;
	   }
	}

	for(int i=0;i<users;i++) {
		printf("Waiting for thread %d to exit\n",i);
		// Waiting for thread i to exit
		pthread_join(threads[i], NULL);
	}

	time_t experiment_ended = time(NULL);

	int total_requests_served = 0;
	float total_response_times = 0;
	
	// Processing Stats
	for(int i=0;i<users;i++) {
		total_requests_served += requests_served[i];
		total_response_times += response_times[i];
	}

	printf("Done!\n");
	printf("throughput = %.3f req/s\n", (total_requests_served*1.0)/(experiment_ended-experiment_started));
	printf("average response time = %.3f sec\n", total_response_times/(experiment_ended-experiment_started));

	return 0;
}

int get_rand(int start, int end) {
	return rand()%(end-start)+start;
}

void *new_user(void *threadid)
{

	long thread_id = (long)threadid;
	time_t start_time = time(NULL);
	requests_served[thread_id] = 0;
	response_times[thread_id] = 0;


	struct sockaddr_in serv_addr;
	serv_addr.sin_family = AF_INET; // host byte order works for this
	serv_addr.sin_port = htons(serv_port); // convert to network byte order, short
	if(inet_aton(serv_ip, &(serv_addr.sin_addr)) == 0) { // can also pick up ip directly from machine: Beej pg 14
		perror("Error on assigning IP address to socket");
		pthread_exit(NULL);
	}
	memset(&(serv_addr.sin_zero), '\0', 8); // zero the rest of the struct

	while ((time(NULL)-start_time) <= duration) {	
		
		int my_sockfd = socket(AF_INET, SOCK_STREAM, 0); // setting up socket fd
		if (my_sockfd < 0) {
			perror("Error on opening socket");
			pthread_exit(NULL);
		}

		
		if(connect(my_sockfd, (struct sockaddr *)&serv_addr, sizeof(struct sockaddr)) < 0) { // binding socket and address 
			perror("Could not connect to destination");
			pthread_exit(NULL);
		}
		int yes = 1;
		if (setsockopt(my_sockfd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(int)) == -1) { // remove the address already in use
			perror("setsockopt");
			pthread_exit(NULL);
		}

		
		// send request to the server
		int file_number = 0;
		if (mode == "random") { // randomly generate file request
			file_number = get_rand(0,9000);
		}
		else {
			// assert (mode == "fixed");
		}

		string str = "get files/foo"+to_string(file_number)+".txt";
		char data[BUF_SIZE];
		strcpy(data,str.c_str()); data[str.length()] = '\0';
		int len = strlen(data);
		int bsent = send(my_sockfd, data, len, 0) ;
		if(bsent != len)
		{
			perror("Sorry, the whole message wasn't sent!");
			pthread_exit(NULL);
		}

		time_t start_time_request = time(NULL);

		//read incoming file
		char buf[256];
		int total_read = 0;
		while (true) {
			int numbytes= recv(my_sockfd, buf, sizeof(buf), 0);
			total_read += numbytes;

			if (numbytes == 0) { // This happens when the socket on the other end closes
				requests_served[thread_id]++;
				response_times[thread_id]+=time(NULL)-start_time_request;
				break; // Exit
			}
			else if(numbytes == -1) { // Error

			}
		}
		close(my_sockfd); // Close socket

		// think-wait
		unsigned int microseconds = think_time*1000000;
		usleep(microseconds);
	}

	pthread_exit(NULL); // Exit thread
}
